import React, { useState } from "react";
import ProductList from "./components/ProductList";
import OrderForm from "./components/OrderForm";
import OrderStatus from "./components/OrderStatus";

function App() {
  const [cart, setCart] = useState([]);

  const handleAddToOrder = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Simple E-Commerce Platform</h1>
      <ProductList onAddToOrder={handleAddToOrder} />
      <hr />
      <OrderForm cart={cart} />
      <hr />
      <OrderStatus />
    </div>
  );
}

export default App;
