import React, { useState } from "react";
import { createOrder } from "../api";

function OrderForm({ cart }) {
  const [message, setMessage] = useState("");

  const handleSubmit = async () => {
    if (cart.length === 0) return alert("Cart is empty!");
    const order = await createOrder({ items: cart });
    setMessage(`Order Created! Your Order ID: ${order.id}`);
  };

  return (
    <div>
      <h2>Create Order</h2>
      <button onClick={handleSubmit}>Place Order</button>
      {message && <p>{message}</p>}
    </div>
  );
}

export default OrderForm;
