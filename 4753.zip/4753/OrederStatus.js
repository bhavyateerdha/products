import React, { useState } from "react";
import { getOrderStatus } from "../api";

function OrderStatus() {
  const [orderId, setOrderId] = useState("");
  const [status, setStatus] = useState("");

  const handleTrack = async () => {
    const result = await getOrderStatus(orderId);
    setStatus(result.status);
  };

  return (
    <div>
      <h2>Track Order Status</h2>
      <input
        type="text"
        placeholder="Enter Order ID"
        value={orderId}
        onChange={(e) => setOrderId(e.target.value)}
      />
      <button onClick={handleTrack}>Track</button>
      {status && <p>Order Status: {status}</p>}
    </div>
  );
}

export default OrderStatus;
