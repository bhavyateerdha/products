const API_BASE = "https://example.com/api"; 

export const fetchProducts = async () => {
  const res = await fetch(`${API_BASE}/products`);
  return res.json();
};

export const createOrder = async (orderData) => {
  const res = await fetch(`${API_BASE}/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(orderData),
  });
  return res.json();
};

export const getOrderStatus = async (orderId) => {
  const res = await fetch(`${API_BASE}/orders/${orderId}/status`);
  return res.json();
};
